﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BLL.DTOs;
using BLL.Services;

namespace Cars.Controllers
{
    public class RentalController : ApiController
    {


        [HttpGet]
        [Route("api/rental/{id}")]
        public HttpResponseMessage Get(int id)
        {
            var data = RentalService.Get(id);
            if (data != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "Rental record not found");
        }

        [HttpPost]
        [Route("api/rental/create")]
        public HttpResponseMessage Create(RentalDTO rentalDto)
        {
            RentalService.Create(rentalDto);
            return Request.CreateResponse(HttpStatusCode.Created, "Rental record created successfully");
        }

        [HttpPut]
        [Route("api/rental/update/{id}")]
        public HttpResponseMessage Update(int id, RentalDTO rentalDto)
        {
            var success = RentalService.Update(id, rentalDto);
            if (success)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Rental record updated successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "Rental record not found");
        }

        [HttpDelete]
        [Route("api/rental/delete/{id}")]
        public HttpResponseMessage Delete(int id)
        {
            var success = RentalService.Delete(id);
            if (success)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Rental record deleted successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "Rental record not found");
        }
        [HttpGet]
        [Route("api/rental/history/{userId}")]
        public HttpResponseMessage GetRentalHistory(int userId)
        {
            var data = RentalService.GetRentalHistory(userId);
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
    }
}
