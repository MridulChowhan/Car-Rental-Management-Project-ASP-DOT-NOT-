﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BLL.DTOs;
using BLL.Services;

namespace Cars.Controllers
{
    public class CarsController : ApiController
    {
        [HttpGet]
        [Route("api/cars/all")]
        public HttpResponseMessage GetAll()
        {
            var data = CarsService.GetAll();
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
        [HttpGet]
        [Route("api/cars/{id}")]
        public HttpResponseMessage Get(int id)
        {
            var data = CarsService.Get(id);
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
        [HttpPost]
        [Route("api/cars/create")]
        public HttpResponseMessage Create(CarsDTO s)
        {
            CarsService.Create(s);
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPut]
        [Route("api/cars/update/{id}")]
        public HttpResponseMessage Update(int id, CarsDTO s)
        {
            var result = CarsService.Update(id, s);
            if (result)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Cars updated successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "Cars not found");
        }


        [HttpDelete]
        [Route("api/cars/delete/{id}")]
        public HttpResponseMessage Delete(int id)
        {
            var result = CarsService.Delete(id);
            if (result)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Cars deleted successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "Cars not found");
        }

        [HttpGet]
        [Route("api/cars/available")]
        public HttpResponseMessage GetAvailableCars()
        {
            var data = CarsService.GetAvailableCars();
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
    }
}
