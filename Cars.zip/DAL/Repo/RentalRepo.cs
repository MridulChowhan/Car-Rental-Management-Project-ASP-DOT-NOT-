﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.EF;
using System.Data.Entity;

namespace DAL.Repo
{
    public class RentalRepo
    {
        private CMSContext db;

        public RentalRepo()
        {
            db = new CMSContext();
        }

        public List<rental> GetAll()
        {
            return db.RentalRecords
                     .Include(r => r.Car)
                     .Include(r => r.Customer)
                     .ToList();
        }

        public rental Get(int id)
        {
            return db.RentalRecords
                     .Include(r => r.Car)
                     .Include(r => r.Customer)
                     .FirstOrDefault(r => r.Id == id);
        }

        public void Create(rental rental)
        {
            if (rental == null)
            {
                throw new ArgumentNullException(nameof(rental), "Rental object cannot be null.");
            }

            if (rental.CarId <= 0 || rental.CustomerId <= 0 || rental.RentalDate == default)
            {
                throw new ArgumentException("Rental object contains invalid or missing required data.");
            }
            db.RentalRecords.Add(rental);
            db.SaveChanges();
        }

        public void Update(rental rental)
        {
            var existingRental = Get(rental.Id);
            if (existingRental != null)
            {
                db.Entry(existingRental).CurrentValues.SetValues(rental);
                db.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var rental = Get(id);
            if (rental != null)
            {
                db.RentalRecords.Remove(rental);
                db.SaveChanges();
            }
        }
    }
}
