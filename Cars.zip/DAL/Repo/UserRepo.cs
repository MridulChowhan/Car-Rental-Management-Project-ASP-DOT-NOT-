﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.EF;
using System.Data.Entity;


namespace DAL.Repo
{
    public class UserRepo
    {
        private CMSContext db;

        public UserRepo()
        {
            db = new CMSContext();
        }

        public void Register(User user)
        {
            db.Users.Add(user);
            db.SaveChanges();
        }

        public User Login(string username, string password)
        {
            return db.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
        }

        public bool Exists(string username)
        {
            return db.Users.Any(u => u.Username == username);
        }
    }
}
