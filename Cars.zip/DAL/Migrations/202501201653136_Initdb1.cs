﻿namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initdb1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.rentals",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CarId = c.Int(nullable: false),
                        CustomerId = c.Int(nullable: false),
                        RentalDate = c.DateTime(nullable: false),
                        ReturnDate = c.DateTime(),
                        TotalPrice = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Cars", t => t.CarId, cascadeDelete: true)
                .ForeignKey("dbo.Users", t => t.CustomerId, cascadeDelete: true)
                .Index(t => t.CarId)
                .Index(t => t.CustomerId);
            
            AddColumn("dbo.Cars", "Model", c => c.String());
            AddColumn("dbo.Cars", "RentalPrice", c => c.String());
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.rentals", "CustomerId", "dbo.Users");
            DropForeignKey("dbo.rentals", "CarId", "dbo.Cars");
            DropIndex("dbo.rentals", new[] { "CustomerId" });
            DropIndex("dbo.rentals", new[] { "CarId" });
            DropColumn("dbo.Cars", "RentalPrice");
            DropColumn("dbo.Cars", "Model");
            DropTable("dbo.rentals");
        }
    }
}
