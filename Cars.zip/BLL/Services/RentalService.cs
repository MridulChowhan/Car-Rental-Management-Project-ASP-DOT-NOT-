﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BLL.DTOs;
using DAL.EF;
using DAL.Repo;

namespace BLL.Services
{
    public class RentalService
    {
        public static List<RentalDTO> GetAll()
        {
            var repo = new RentalRepo();
            var data = repo.GetAll();

            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<rental, RentalDTO>();
                        });
            var mapper = new Mapper(config);
            return mapper.Map<List<RentalDTO>>(data);
        }

        public static RentalDTO Get(int id)
        {
            var repo = new RentalRepo();
            var data = repo.Get(id);

            if (data == null) return null;


            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<rental, RentalDTO>();
            });

            var mapper = new Mapper(config);
            return mapper.Map<RentalDTO>(data);
        }

        public static void Create(RentalDTO rentalDto)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<RentalDTO, rental>();
            });

            var mapper = new Mapper(config);
            var rental = mapper.Map<rental>(rentalDto);

            var repo = new RentalRepo();
            repo.Create(rental);
        }
        public static bool Update(int id, RentalDTO rentalDto)
        {
            var repo = new RentalRepo();
            var existingRental = repo.Get(id);
            if (existingRental == null) return false;

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<RentalDTO, rental>();
            });

            var mapper = new Mapper(config);
            var updatedRental = mapper.Map<rental>(rentalDto);
            updatedRental.Id = id;

            repo.Update(updatedRental);
            return true;
        }

        public static bool Delete(int id)
        {
            var repo = new RentalRepo();
            var existingRental = repo.Get(id);
            if (existingRental == null) return false;

            repo.Delete(id);
            return true;
        }
        public static List<RentalDTO> GetRentalHistory(int userId)
        {
            var rentalRepo = new RentalRepo();
            var rentals = rentalRepo.GetAll().Where(r => r.Customer.Id == userId).ToList();
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<rental, RentalDTO>();
            });
            var mapper = new Mapper(config);
            var rentalHistory = mapper.Map<List<RentalDTO>>(rentals);

            return rentalHistory;
        }
    }
}
