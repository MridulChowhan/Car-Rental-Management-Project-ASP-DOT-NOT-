﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BLL.DTOs;
using DAL.EF;
using DAL.Repo;

namespace BLL.Services
{
    public class CarsService
    {
        public static List<CarsDTO> GetAll()
        {
            var srepo = new CarsRepo();
            var data = srepo.Get();
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<Cars, CarsDTO>();
            });
            var mapper = new Mapper(config); ;
            var ret = mapper.Map<List<CarsDTO>>(data);

            return ret;

        }
        public static CarsDTO Get(int id)
        {
            var srepo = new CarsRepo();
            var data = srepo.Get(id);
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<Cars, CarsDTO>();
            });
            var mapper = new Mapper(config); ;
            var ret = mapper.Map<CarsDTO>(data);

            return ret;

        }
        public static void Create(CarsDTO s)
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<CarsDTO, Cars>();
            });
            var mapper = new Mapper(config); ;
            var st = mapper.Map<Cars>(s);
            var repo = new CarsRepo();
            repo.Create(st);

        }
        public static bool Update(int id, CarsDTO s)
        {
            var repo = new CarsRepo();
            var existingNews = repo.Get(id);
            if (existingNews == null)
            {
                return false;
            }

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CarsDTO, Cars>();
            });
            var mapper = new Mapper(config);
            var updatedNews = mapper.Map<Cars>(s);
            updatedNews.Id = id;
            repo.Update(updatedNews);
            return true;
        }


        public static bool Delete(int id)
        {
            var repo = new CarsRepo();
            var existingNews = repo.Get(id);
            if (existingNews == null)
            {
                return false;
            }
            repo.Delete(id);
            return true;
        }
        public static List<CarsDTO> GetAvailableCars()
        {
            var srepo = new CarsRepo();
            var data = srepo.Get().Where(c => c.Available == "True").ToList(); 
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<Cars, CarsDTO>();
            });
            var mapper = new Mapper(config);
            var ret = mapper.Map<List<CarsDTO>>(data);

            return ret;
        }
    }
}
