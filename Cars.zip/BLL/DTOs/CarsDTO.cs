﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class CarsDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Model { get; set; } 
        public string Price { get; set; }
        public string RentalPrice { get; set; } 
        public string Available { get; set; }
    }
}
